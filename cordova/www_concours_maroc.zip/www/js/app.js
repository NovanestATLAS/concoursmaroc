/* Concours Maroc (Android app) — bootstrap.
 *
 * Start order: router and first page (needs nothing native) -> optional
 * native services (speech, ads), each bounded in time, so a plugin that never
 * answers costs a feature, never a blank screen. Same lifecycle as the first
 * version: deviceready, a browser path, and a watchdog.
 */
(function (global) {
  'use strict';

  var Shell = global.CM.shell;
  var Store = global.CM.store;
  var TTS = global.CM.tts;
  var Ads = global.CM.ads;
  var Play = global.CM.play;
  var Firebase = global.CM.firebase;
  var Notices = global.CM.notices;
  var Dev = global.CM.dev;
  var Live = global.CM.live;
  var booted = false;

  function tr(fr, ar) { return Shell.lang() === 'ar' ? ar : fr; }
  function toast(msg) { if (global.cmToast) global.cmToast(msg); }
  function locale() { return Shell.lang() === 'ar' ? 'ar-MA' : 'fr-FR'; }
  function dateText(iso) {
    if (!iso) return '';
    try { return new Date(iso + 'T12:00:00').toLocaleDateString(locale(), { day: 'numeric', month: 'long', year: 'numeric' }); } catch (e) { return iso; }
  }

  /* Message for the result of a content check (js/live.js). */
  function liveMessage(r) {
    switch (r && r.status) {
      case 'updated': return tr('Contenu mis à jour : nouveautés du ', 'تم تحديث المحتوى: مستجدات ') + dateText(r.updated);
      case 'uptodate': case 'skipped': return tr('Le contenu est déjà à jour', 'المحتوى محيَّن');
      case 'offline': return tr('Pas de connexion : réessayez plus tard', 'لا يوجد اتصال: أعد المحاولة لاحقًا');
      case 'app-update': return tr('Ce nouveau contenu demande la dernière version de l’application', 'يتطلب هذا المحتوى الجديد آخر نسخة من التطبيق');
      default: return tr('Vérification impossible pour le moment', 'تعذر التحقق حاليًا');
    }
  }

  function withTimeout(promise, ms, label) {
    return new Promise(function (resolve, reject) {
      var done = false;
      var timer = setTimeout(function () {
        if (done) return;
        done = true;
        reject(new Error((label || 'operation') + ' : aucune réponse après ' + ms + ' ms'));
      }, ms);
      Promise.resolve(promise).then(function (v) {
        if (done) return;
        done = true; clearTimeout(timer); resolve(v);
      }, function (e) {
        if (done) return;
        done = true; clearTimeout(timer); reject(e);
      });
    });
  }

  function fail(err) {
    var host = document.getElementById('view');
    if (!host) return;
    host.innerHTML = '';
    var box = document.createElement('div');
    box.className = 'container app-boot';
    var p = document.createElement('p');
    p.textContent = 'Erreur de chargement / خطأ في التحميل';
    var d = document.createElement('p');
    d.className = 'err';
    d.textContent = String(err && err.message ? err.message : err);
    var b = document.createElement('button');
    b.className = 'btn';
    b.type = 'button';
    b.textContent = 'Réessayer / إعادة المحاولة';
    b.onclick = function () { global.location.reload(); };
    box.appendChild(p); box.appendChild(d); box.appendChild(b);
    host.appendChild(box);
  }

  // ------------------------------------------------------------ status bar
  function syncStatusBar() {
    var dark = document.documentElement.getAttribute('data-theme') === 'dark';
    var color = dark ? '#0f1730' : '#ffffff';   // background of the header, per theme
    try {
      if (global.StatusBar && typeof global.StatusBar.backgroundColorByHexString === 'function') {
        // cordova-plugin-statusbar, when installed: it also needs the icon style
        global.StatusBar.backgroundColorByHexString(color);
        if (dark) global.StatusBar.styleLightContent(); else global.StatusBar.styleDefault();
      } else if (global.statusbar && typeof global.statusbar.setBackgroundColor === 'function') {
        // built into cordova-android 15+: takes a CSS colour and picks the
        // icon contrast itself
        global.statusbar.setBackgroundColor(color);
      }
    } catch (e) { /* cosmetic only */ }
  }
  document.addEventListener('cm:theme', syncStatusBar);

  /* Edge-to-edge (WebView drawn under the status bar) only when the page is
     as tall as the screen; otherwise the safe areas are ignored (shell.css). */
  function detectEdge() {
    var gap = (global.screen && global.screen.height ? global.screen.height : 0) - global.innerHeight;
    document.documentElement.toggleAttribute('data-edge', gap < 8);
  }
  detectEdge();

  // ------------------------------------------------------------ advertising
  /* The banner is on every screen; interstitials only at the transitions
     reported here (screen changes, results of a finished set), never while
     a question is on screen. All the rules are in ads-service.js. */
  var onPlay = false;
  var handled = {};

  function syncBanner() { if (Ads) Ads.syncBanner(); }

  document.addEventListener('cm:page', function (e) {
    var d = e.detail || {};
    if (!d.practice) onPlay = false;
    syncBanner();
    // the practice page reports its own screens (cm:route)
    if (Ads && !d.practice) Ads.screenChanged();
  });

  document.addEventListener('cm:route', function (e) {
    var d = e.detail || {};
    onPlay = d.name === 'quiz' || d.name === 'memoire';
    syncBanner();
    if (!Ads) return;
    if (onPlay) { Ads.questionOnScreen(); return; }
    if (d.name === 'results' && d.previous === 'quiz') {
      var sum = Store.read('lastSummary', null);
      if (sum && !handled[sum.sessionId]) {
        handled[sum.sessionId] = true;
        var adShown = Ads.setFinished(sum);
        // Google's review card, when due, never on a set that has its ad
        if (Play) Play.sessionFinished(sum, adShown);
        return;
      }
    }
    Ads.screenChanged();
  });

  // between two practice questions (src/js/entrainement/ui.js)
  document.addEventListener('cm:question-break', function () { if (Ads && onPlay) Ads.questionBreak(); });

  /* Ad rules published with the website (content/app-ads.json →
     <site>/app/ads.json): the frequency of interstitials can change without
     a new version. JSON only, bounded in ads-service.js; the last rules read
     are kept for offline starts. */
  var RULES_KEY = 'cm.adRules';
  function applyStoredRules() {
    try { var r = JSON.parse(localStorage.getItem(RULES_KEY) || 'null'); if (r && Ads) Ads.applyRules(r); } catch (e) { /* ignore */ }
  }
  function fetchRules() {
    if (!Ads || !global.fetch) return;
    var site = (document.documentElement.getAttribute('data-site-url') || 'https://www.maroc-concour.com/').replace(/\/?$/, '/');
    global.fetch(site + 'app/ads.json', { cache: 'no-cache' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (r) {
        if (!r || typeof r !== 'object') return;
        try { localStorage.setItem(RULES_KEY, JSON.stringify(r)); } catch (e) { /* ignore */ }
        Ads.applyRules(r);
      })
      .catch(function () { /* offline: the stored rules stay */ });
  }
  applyStoredRules();
  var rulesAt = 0;
  function refreshRules() { if (Date.now() - rulesAt > 6 * 3600000) { rulesAt = Date.now(); fetchRules(); } }
  refreshRules();
  document.addEventListener('resume', refreshRules);

  // ------------------------------------------------------------ back button
  var lastBack = 0;
  function closeOverlays() {
    var UI = global.CM.ui;
    if (UI && UI.isSheetOpen && UI.isSheetOpen()) { UI.closeSheet(); return true; }
    var nav = document.getElementById('site-nav');
    if (nav && nav.classList.contains('open')) {
      nav.classList.remove('open');
      var menu = document.getElementById('menu-btn');
      if (menu) menu.setAttribute('aria-expanded', 'false');
      return true;
    }
    var panel = document.getElementById('search-panel');
    if (panel && panel.classList.contains('open')) { panel.classList.remove('open'); return true; }
    return false;
  }

  function back(allowExit) {
    if (closeOverlays()) return;
    if (TTS && TTS.isSpeaking && TTS.isSpeaking()) TTS.stop();
    if (Shell.back()) return;
    if (!allowExit) return;
    if (Date.now() - lastBack < 2000) {
      if (navigator.app && navigator.app.exitApp) navigator.app.exitApp();
      return;
    }
    lastBack = Date.now();
    toast(tr('Appuyez encore sur Retour pour quitter', 'اضغط مرة أخرى على زر الرجوع للخروج'));
  }

  document.addEventListener('backbutton', function (e) {
    if (e && e.preventDefault) e.preventDefault();
    back(true);
  }, false);

  var backBtn = document.getElementById('app-back');
  if (backBtn) backBtn.addEventListener('click', function () { back(false); });

  // Escape mirrors the hardware button in a desktop preview.
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && !(global.CM.ui && global.CM.ui.isSheetOpen && global.CM.ui.isSheetOpen())) closeOverlays();
  });

  // ------------------------------------------------------------ lifecycle
  document.addEventListener('resume', function () {
    // back from an interstitial, Google's review card or the store page:
    // not a return of the user, nothing to check
    if (Ads && Ads.resumedFromAd && Ads.resumedFromAd()) return;
    if (Play) Play.checkUpdate(false, true);
    if (Notices) setTimeout(function () { Notices.check(false, false); }, 1500);
    if (Live) setTimeout(function () { Live.check(false); }, 2500);
  }, false);

  // New content downloaded during the session (js/live.js): the next pages
  // opened show it. Said once, never over a question.
  document.addEventListener('cm:live', function (e) {
    var d = e.detail || {};
    if (!onPlay) toast(liveMessage({ status: 'updated', updated: d.updated }));
  });

  document.addEventListener('pause', function () {
    if (TTS) TTS.stop();
    var Q = global.CM.quiz;
    try { if (Q && Q.current() && !Q.current().finished) Q.save(); } catch (e) { /* ignore */ }
  }, false);

  function initNativeServices() {
    syncStatusBar();
    withTimeout(TTS.init(Store.getProfile().tts), 6000, 'tts')
      .then(function (s) { if (s && s.available) console.info('[app] tts prête (' + s.engine + ', ' + s.voiceCount + ' voix)'); })
      .catch(function (e) { console.warn('[app] tts indisponible :', e.message); });
    if (Firebase) {
      try { Firebase.init(Shell.lang()); } catch (e) { console.warn('[app] firebase :', e.message); }
    }
    // dialogs open at calm moments only (CM.ads.popups): the update window
    // first, the announcement if any, the monthly review message later
    if (Play) {
      Play.appOpened();
      setTimeout(function () { Play.checkUpdate(); }, 3000);
    }
    if (Notices) setTimeout(function () { Notices.check(false, true); }, 8000);
    withTimeout(Ads.init(Store.getProfile().ads), 10000, 'ads')
      .then(syncBanner)
      .catch(function (e) { console.warn('[app] publicité indisponible :', e.message); });
  }

  function boot(trigger) {
    if (booted) return;
    booted = true;
    console.info('[app] démarrage (' + trigger + ')');
    // content downloaded from the website, if any (bounded: never a blank screen)
    var content = Live ? withTimeout(Live.init(), 4000, 'contenu en ligne').catch(function (e) {
      console.warn('[app] contenu en ligne :', e.message);
    }) : Promise.resolve();
    content.then(function () { return Shell.start(); }).then(function () {
      global.CM.appStarted = true;
      if (Live) Live.started();
      initNativeServices();
    }).catch(function (err) {
      console.error('[app] démarrage impossible', err);
      // downloaded content that breaks the start is dropped: start again with
      // the content of the APK
      if (Live && Live.failed()) { global.location.reload(); return; }
      fail(err);
    });
  }

  document.addEventListener('deviceready', function () { boot('deviceready'); }, false);
  function bootIfNoCordova() { setTimeout(function () { if (!global.cordova) boot('navigateur'); }, 0); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bootIfNoCordova);
  else bootIfNoCordova();
  // cordova.js present but deviceready never fired (a plugin failed to start):
  // start anyway, native services are optional.
  setTimeout(function () { if (!booted) boot('watchdog'); }, 5000);

  // ------------------------------------------------------------ settings page
  Shell.onInit('settings', function (root) {
    var theme = root.querySelector('#set-theme');
    if (theme) {
      var cur = 'auto';
      try { cur = localStorage.getItem('cm.theme') || 'auto'; } catch (e) { /* ignore */ }
      theme.value = cur;
      theme.addEventListener('change', function () {
        var v = theme.value;
        try { localStorage.setItem('cm.theme', v); } catch (e) { /* ignore */ }
        var eff = v === 'auto' ? (global.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light') : v;
        document.documentElement.setAttribute('data-theme', eff);
        syncStatusBar();
      });
    }

    var status = root.querySelector('#set-tts-status');
    function fillVoices() {
      var st = TTS.status ? TTS.status() : { available: TTS.isAvailable() };
      if (status) {
        status.textContent = !st.available
          ? tr('Aucun moteur de synthèse vocale détecté. Installez « Services de synthèse vocale Google » depuis le Play Store.', 'لم يتم العثور على محرك للقراءة الصوتية. ثبّت «خدمات Google للنطق» من متجر Play.')
          : tr('Moteur : ', 'المحرك: ') + (st.engine === 'native' ? tr('Android (hors ligne)', 'أندرويد (بدون إنترنت)') : tr('navigateur', 'المتصفح')) + ' · ' + (st.voiceCount || 0) + tr(' voix', ' صوتًا');
      }
      [['fr', '#set-voice-fr', 'voiceFr'], ['ar', '#set-voice-ar', 'voiceAr']].forEach(function (cfg) {
        var sel = root.querySelector(cfg[1]);
        if (!sel) return;
        while (sel.firstChild) sel.removeChild(sel.firstChild);
        var auto = document.createElement('option');
        auto.value = '';
        auto.textContent = tr('Automatique', 'تلقائي');
        sel.appendChild(auto);
        (TTS.voicesFor(cfg[0]) || []).forEach(function (v) {
          var o = document.createElement('option');
          o.value = v.id;
          o.textContent = v.name + (v.lang ? ' (' + v.lang + ')' : '');
          sel.appendChild(o);
        });
        sel.value = (Store.getProfile().tts || {})[cfg[2]] || '';
        sel.onchange = function () {
          var patch = { tts: {} };
          patch.tts[cfg[2]] = sel.value || null;
          Store.patchProfile(patch);
          TTS.setPrefs(Store.getProfile().tts);
        };
      });
    }
    fillVoices();
    if (TTS.init && TTS.status && !TTS.status().ready) {
      TTS.init(Store.getProfile().tts).then(fillVoices, fillVoices);
    }
    Array.prototype.forEach.call(root.querySelectorAll('[data-tts-test]'), function (b) {
      b.addEventListener('click', function () {
        var lang = b.getAttribute('data-tts-test');
        if (TTS.preview) TTS.preview(lang); else TTS.speak(lang === 'ar' ? 'مرحبًا' : 'Bonjour', lang);
      });
    });
    var openTts = root.querySelector('#set-tts-open');
    if (openTts) {
      openTts.hidden = !(TTS.canOpenSettings && TTS.canOpenSettings());
      openTts.addEventListener('click', function () { TTS.openSettings(); });
    }

    var consent = root.querySelector('#set-consent');
    var adsInfo = root.querySelector('#set-ads-status');
    function adsText() {
      var s = Ads.status();
      if (!adsInfo) return;
      adsInfo.textContent = s.mode === 'native'
        ? tr('Publicités Google AdMob actives', 'إعلانات Google AdMob مفعلة') + (s.testMode ? tr(' (mode test)', ' (وضع الاختبار)') : '')
        : tr('Aucune publicité dans cette version', 'لا توجد إعلانات في هذه النسخة');
    }
    adsText();
    if (consent) {
      // Google's consent tool says whether a way to change the choices is
      // required (users in the EEA, the UK…).
      var syncConsent = function () { consent.hidden = !Ads.status().privacyOptions; };
      syncConsent();
      Ads.on('consent', syncConsent);
      consent.addEventListener('click', function () {
        Ads.showConsentForm().then(function () { adsText(); toast(tr('Choix enregistrés', 'تم حفظ اختياراتك')); });
      });
    }

    // Firebase: notifications and usage statistics (card shown with the plugins)
    var fbCard = root.querySelector('#set-firebase');
    if (fbCard && Firebase) {
      var present = Firebase.present();
      fbCard.hidden = !(present.analytics || present.messaging);
      var alerts = root.querySelector('#set-alerts');
      var stats = root.querySelector('#set-analytics');
      var setSw = function (b, on) { if (b) b.setAttribute('aria-checked', on ? 'true' : 'false'); };
      if (alerts) {
        alerts.closest('.switch-row').hidden = !present.messaging;
        setSw(alerts, Firebase.notificationsOn());
        alerts.addEventListener('click', function () {
          var on = alerts.getAttribute('aria-checked') !== 'true';
          alerts.disabled = true;
          (on ? Firebase.enableNotifications(Shell.lang()) : Firebase.disableNotifications()).then(function (r) {
            alerts.disabled = false;
            setSw(alerts, r === 'on');
            if (on && r !== 'on') toast(tr('Notifications refusées : autorisez-les dans les réglages Android de l’application.', 'تم رفض الإشعارات: فعّلها من إعدادات أندرويد الخاصة بالتطبيق.'));
            else toast(r === 'on' ? tr('Alertes activées', 'تم تفعيل التنبيهات') : tr('Alertes désactivées', 'تم إيقاف التنبيهات'));
          });
        });
      }
      if (stats) {
        stats.closest('.switch-row').hidden = !present.analytics;
        setSw(stats, Firebase.analyticsOn());
        stats.addEventListener('click', function () {
          var on = stats.getAttribute('aria-checked') !== 'true';
          setSw(stats, on);
          Firebase.setAnalytics(on);
        });
      }
    }

    var rate = root.querySelector('#set-rate');
    if (rate && Play) {
      rate.hidden = !(global.LaunchReview || global.PlayUpdate);
      rate.addEventListener('click', function () { Play.openStorePage(); });
    }
    var upd = root.querySelector('#set-update');
    if (upd && Play) {
      upd.hidden = !Play.updateAvailable();
      upd.addEventListener('click', function () {
        Play.checkUpdate(true).then(function (info) {
          if (!info) toast(tr('Vérification impossible pour le moment', 'تعذر التحقق حاليًا'));
          else if (info.availability !== 'available' && info.availability !== 'in_progress') toast(tr('Vous avez la dernière version', 'لديك أحدث نسخة'));
        });
      });
    }

    // developer mode: six taps on "À propos"
    var devLink = root.querySelector('#set-dev');
    if (Dev) {
      if (devLink) devLink.hidden = !Dev.enabled();
      Dev.attachTaps([root.querySelector('#set-about-title'), root.querySelector('#set-version-line')], function () {
        if (devLink) devLink.hidden = false;
      });
    }

    var version = root.querySelector('#set-version');
    function showVersion() {
      if (!version) return;
      global.CM.load.json('data/manifest.json').then(function (m) {
        // LRI … PDI: in Arabic the bidi algorithm would otherwise show "2.0.0-2026-11-09" as "09-11-2026-2.0.0"
        version.textContent = '\u2066' + (m.contentVersion || '') + '\u2069 · ' + (m.totalQuestions || 0) + tr(' questions', ' سؤالًا');
      }).catch(function () { /* ignore */ });
    }
    showVersion();

    // content kept up to date from the website (js/live.js)
    var liveLine = root.querySelector('#set-live-line');
    var liveText = root.querySelector('#set-live');
    var liveBtn = root.querySelector('#set-live-check');
    if (Live && Live.supported() && liveLine && liveText) {
      var showLive = function () {
        var s = Live.status();
        var checked = '';
        if (s.checked) {
          try { checked = new Date(s.checked).toLocaleString(locale(), { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }); } catch (e) { checked = ''; }
        }
        liveText.textContent = tr('contenu du ', 'محتوى ') + dateText(Live.contentDate()) + (checked ? tr(' · vérifié le ', ' · آخر تحقق ') + checked : '');
        liveLine.hidden = false;
      };
      showLive();
      if (liveBtn) {
        liveBtn.hidden = false;
        liveBtn.addEventListener('click', function () {
          liveBtn.disabled = true;
          Live.check(true).then(function (r) {
            liveBtn.disabled = false;
            // 'updated' is announced by the cm:live toast
            if (r.status !== 'updated') toast(liveMessage(r));
            showLive();
            showVersion();
          });
        });
      }
    }
  });

  if (Dev) Shell.onInit('developer', Dev.render);

  global.CM.boot = { back: back, syncBanner: syncBanner, isPlaying: function () { return onPlay; } };
})(window);
